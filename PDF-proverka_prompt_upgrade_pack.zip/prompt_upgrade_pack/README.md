# Prompt upgrade pack for PDF-proverka-main

Этот пакет не копирует multi-agent архитектуру из `2-Multi-Agent-Manager-master` целиком.
Вместо этого он переносит её полезную логику в **компактный дисциплинарный слой** для `PDF-proverka-main`.

Что внутри:
- `ANALYSIS_REPORT.md` — выводы по сравнению двух проектов и почему именно так лучше усиливать промты.
- `ready_to_apply/` — готовые файлы для подмены в `PDF-proverka-main`.
- `compiled_previews/` — предпросмотр дисциплинарно-усиленных промтов по стадиям `text_analysis` и `block_analysis`.

Базовая идея интеграции:
1. оставить единый pipeline;
2. добавить в дисциплины файл `compact_strategy.md`;
3. использовать в шаблонах уже существующие `{DISCIPLINE_TEXT_ANALYSIS}` и `{DISCIPLINE_TRIAGE_TABLE}`;
4. добавить новый placeholder `{DISCIPLINE_COMPACT_STRATEGY}`;
5. не раздувать prompt полными ownership-matrix и десятками R1-промтов.

Минимальный набор файлов для внедрения:
- `webapp/services/discipline_service.py`
- `.claude/text_analysis_task.md`
- `.claude/en/text_analysis_task.md`
- `.claude/block_analysis_task.md`
- `.claude/en/block_analysis_task.md`
- `disciplines/*/compact_strategy.md`

Опционально для UI:
- `webapp/static/js/app.js`
